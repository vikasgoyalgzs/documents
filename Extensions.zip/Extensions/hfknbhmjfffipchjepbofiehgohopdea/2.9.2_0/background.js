/* ***** BEGIN LICENSE BLOCK *****
 *
 * iGetterExtension - adds iGetter contextual menu commands.
 * Copyright (C) 2010-2013 by Presenta Ltd., all rights reserved.
 *
 * ***** END LICENSE BLOCK ***** */

function onClickDownloadLink(info, tab)
{
	try
	{
		var	igetterPlugin = document.getElementById("iGetterScriptablePluginId");
		if (igetterPlugin && info.linkUrl)
		{
			var	referrerUrl = info.frameUrl;
			if (!referrerUrl) referrerUrl = info.pageUrl;
			
			chrome.cookies.getAll({url: info.linkUrl},
				function(cookies)
				{
					try
					{
						var	cookieStr = "";
						for (var j = 0; j < cookies.length; ++j)
						{
							if (cookieStr.length > 0) cookieStr += "; ";
							cookieStr += cookies[j].name + "=" + cookies[j].value;
						}
									  
						igetterPlugin.addURL(info.linkUrl, referrerUrl, cookieStr);
						igetterPlugin.sendURLs();
					}
					catch (e)
					{
						alert("iGetterContextualMenu error: " + e.message);
					}
				});
		}
	}
	catch (err)
	{
		alert("iGetterContextualMenu error: " + err.message);
	}
}

function onClickDownloadSel(info, tab)
{
	try
	{
		var	igetterPlugin = document.getElementById("iGetterScriptablePluginId");
		if (igetterPlugin)
		{
			var	referrerUrl = info.frameUrl;
			if (!referrerUrl) referrerUrl = info.pageUrl;
			
			chrome.tabs.sendRequest(tab.id, {message: "igetterDownloadSel"},
				function(response)
				{
					if (response.links)
					{
						var	numAdded = 0;
						var	len = response.links.length;
						if (len > 0)
						{
							for (var i = 0; i < len; ++i)
							{
								function addLinks(link)
								{
									chrome.cookies.getAll({url: link},
										function(cookies)
										{
											numAdded++;
											try
											{
												var	cookieStr = "";
												for (var j = 0; j < cookies.length; ++j)
												{
													if (cookieStr.length > 0) cookieStr += "; ";
													cookieStr += cookies[j].name + "=" + cookies[j].value;
												}
												
												igetterPlugin.addURL(link, referrerUrl, cookieStr);
														  
												if (numAdded == len)
												{
													if (info.selectionText)
														igetterPlugin.addSelection(info.selectionText, referrerUrl);
													
													igetterPlugin.sendURLs();
												}
											}
											catch (e) { }
										});
								}
								
								addLinks(response.links[i]);
							}
						}
						else
						{
							if (info.selectionText)
								igetterPlugin.addSelection(info.selectionText, referrerUrl);
							
							igetterPlugin.sendURLs();
						}
					}
				});
		}
	}
	catch (err)
	{
		alert("iGetterContextualMenu error: " + err.message);
	}
}

function onClickDownloadAll(info, tab)
{
	try
	{
		var	igetterPlugin = document.getElementById("iGetterScriptablePluginId");
		if (igetterPlugin)
		{
			var	referrerUrl = info.frameUrl;
			if (!referrerUrl) referrerUrl = info.pageUrl;
			
			chrome.tabs.sendRequest(tab.id, {message: "igetterDownloadAll"},
				function(response)
				{
					if (response.links)
					{
						var	numAdded = 0;
						var	len = response.links.length;
						for (var i = 0; i < len; ++i)
						{
							function addLinks(link)
							{
								chrome.cookies.getAll({url: link},
									function(cookies)
									{
										numAdded++;
										try
										{
											var	cookieStr = "";
											for (var j = 0; j < cookies.length; ++j)
											{
												if (cookieStr.length > 0) cookieStr += "; ";
												cookieStr += cookies[j].name + "=" + cookies[j].value;
											}

											igetterPlugin.addURL(link, referrerUrl, cookieStr);

											if (numAdded == len)
												igetterPlugin.sendURLs();
										}
										catch (e) { }
									});
							}

							addLinks(response.links[i]);
						}
					}
				});
		}
	}
	catch (err)
	{
		alert("iGetterContextualMenu error: " + err.message);
	}
}

if (chrome.webRequest)
{
	try
	{
		if (navigator.plugins["iGetter Plugin"])
		{
			chrome.webRequest.onHeadersReceived.addListener(
				function(details)
				{
					try
					{
						if (details.method === "GET")
						{
							var	m;
							var	nameStr;
							var	mimeStr = null;
							var	ind = -1;
							var	len = details.responseHeaders.length;
							for (var i = 0; i < len; ++i)
							{
								nameStr = details.responseHeaders[i].name;
								if (nameStr === "Content-Type")
									mimeStr = details.responseHeaders[i].value;
								else if (nameStr === "Content-Disposition")
									ind = i;
								
								if ((ind >= 0) && mimeStr)
								{
									m = navigator.mimeTypes[mimeStr];
									if (m && m.enabledPlugin && (m.enabledPlugin.name === "iGetter Plugin"))
									{
										details.responseHeaders.splice(ind, 1);

										return {responseHeaders: details.responseHeaders};
									}
															
									break;
								}
							}
						}
					}
					catch (e) { }
					
					return {};
				},
				
				{urls: ["http://*/*", "https://*/*"]},
				["blocking", "responseHeaders"]);
		}
	}
	catch (err) { }
}

if (chrome.contextMenus && chrome.tabs && chrome.cookies)
{
	try
	{
		var	igetterPlugin = document.getElementById("iGetterScriptablePluginId");
		if (igetterPlugin && igetterPlugin.addURL && igetterPlugin.addSelection && igetterPlugin.sendURLs)
		{
			chrome.contextMenus.create({title: chrome.i18n.getMessage("download"), contexts: ["link"], onclick: onClickDownloadLink});
			chrome.contextMenus.create({title: chrome.i18n.getMessage("downloadSel"), contexts: ["selection"],
										onclick: onClickDownloadSel});
			chrome.contextMenus.create({title: chrome.i18n.getMessage("downloadAll"), contexts: ["all"], onclick: onClickDownloadAll});
		}
	}
	catch (err) { }
}
