/* ***** BEGIN LICENSE BLOCK *****
 *
 * iGetterExtension - adds iGetter contextual menu commands.
 * Copyright (C) 2010-2013 by Presenta Ltd., all rights reserved.
 *
 * ***** END LICENSE BLOCK ***** */

chrome.extension.onRequest.addListener(
	function(request, sender, response)
	{
		var	links = [];
		try
		{
			if ((request.message == "igetterDownloadSel") || (request.message == "igetterDownloadAll"))
			{
				function addLink(inLinks, inSel, outLinks)
				{
					for (var i = 0; i < inLinks.length; ++i)
					{
						if (inLinks[i] && (inLinks[i].href != "") &&
							((request.message == "igetterDownloadAll") || inSel.containsNode(inLinks[i], true)))
						{
							outLinks.push(inLinks[i].href);
						}
					}
				}
				
				var	sel = window.getSelection();
				if (document.links)
					addLink(document.links, sel, links);
				
				var	frames = document.getElementsByTagName("frame");
				if (frames)
				{
					for (var j = 0; j < frames.length; ++j)
					{
						sel = frames[j].contentDocument.getSelection();
						if (frames[j].contentDocument.links)
							addLink(frames[j].contentDocument.links, sel, links);
					}
				}
			}
		}
		catch (err)
		{
			alert("iGetterContextualMenu error: " + err.message);
		}
									   
		response({links: links});
	});
