document.location.href = "https://script.google.com/start";
