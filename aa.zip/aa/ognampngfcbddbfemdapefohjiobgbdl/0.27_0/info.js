if (typeof speedtracer == 'undefined') {
  var speedtracer = {};
}
