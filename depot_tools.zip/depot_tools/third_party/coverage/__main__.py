"""Coverage.py's main entry point."""
import sys
from coverage.cmdline import main
sys.exit(main())
