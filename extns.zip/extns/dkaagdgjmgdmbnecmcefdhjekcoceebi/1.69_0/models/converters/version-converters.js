/*

Copyright 2011-2014 Alex Belozerov, Ilya Stepanov

This file is part of PerfectPixel.

PerfectPixel is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

PerfectPixel is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with PerfectPixel.  If not, see <http://www.gnu.org/licenses/>.

*/
var VersionConverter={convert:function(){}},VersionConverter_FromLegacy=_.extend(VersionConverter,{convert:function(a,b){var c=Number(localStorage.currentOverlayId||-1);if(localStorage.options)var d=$.parseJSON(localStorage.options).visible||!1,e=$.parseJSON(localStorage.options).locked||!1;else var d=e=!1;for(var f=[],g=0;localStorage["overlay"+g+"_data"]&&localStorage["overlay"+g+"_position"];){var h=$.parseJSON(localStorage["overlay"+g+"_data"]),i=$.parseJSON(localStorage["overlay"+g+"_position"]),j=_.extend(h,i);j.IsCurrent=g==c,f.push(j),g++}for(var k=new PerfectPixelModel({id:1,overlayShown:d,overlayLocked:e,version:b}),l=0;l<f.length;l++){var m=f[l],n=new Overlay({x:m.X,y:m.Y,width:m.Width,height:m.Height,opacity:m.Opacity,scale:m.Scale,filename:m.FileName,thumbnailFilename:m.ThumbnailFileName});k.overlays.add(n),n.save(),m.IsCurrent&&k.set({currentOverlayId:n.id})}k.save(),localStorage.removeItem("currentOverlayId"),localStorage.removeItem("options");for(var l=0;l<f.length;l++)localStorage.removeItem("overlay"+l+"_data"),localStorage.removeItem("overlay"+l+"_position")}}),VersionConverter_SimpleVersionUpdater=_.extend(VersionConverter,{convert:function(a,b){var c=new PerfectPixelModel({id:1});c.fetch(),c.set("version",b),c.save()}});