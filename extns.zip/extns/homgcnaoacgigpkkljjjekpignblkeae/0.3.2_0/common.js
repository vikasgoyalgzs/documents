/**
 * Chrome AppSniffer
 *
 * Shared functions among scripts
 *
 * @author Bao Nguyen <contact@nqbao.com>
 * @license GPLv3
 **/
 
// to be added ...