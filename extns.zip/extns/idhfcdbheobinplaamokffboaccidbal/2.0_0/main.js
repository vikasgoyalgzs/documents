var startWidth;
var startHeight;
var startURL;
var local = false;
var currentArray;
var backupArray;

chrome.windows.getCurrent(function(w) {
	startWidth = w.width;
	startHeight = w.height;
});

chrome.tabs.getSelected(null, function(t) {
	startURL = t.url;
});

function init(params)
{
	if(params.local != null)
	{
		local = params.local;
	}
	
	var resArray = null;
	
	var closeOnResize = getPref("closeOnResize");
	if(closeOnResize == null || closeOnResize == "" || closeOnResize == undefined || closeOnResize == "undefined")
	{
		setPref("closeOnResize", false);
		closeOnResize = false;
	}
	
	var desktopNotifications = getPref("desktopNotifications");
	if(desktopNotifications == null || desktopNotifications == "" || desktopNotifications == undefined || desktopNotifications == "undefined")
	{
		setPref("desktopNotifications", false);
		desktopNotifications = false;
	}
	
	
	if(params == null || params.fromXML == null || params.fromXML == false)
	{
		resArray = getPref("resolutionArray");
	}
	
	if(resArray == null || resArray == "" || resArray == undefined || resArray == "undefined")
	{
	
		var newArray = [];
		
		$.ajax({
			type: "GET",
			url: "settings.xml",
			dataType: "xml",
			success: function(xml) {
				
				$(xml).find('resolution').each(function(){
					var newResolution = new Array(2);
					newResolution[0] = parseInt($(this).attr('width'));
					newResolution[1] = parseInt($(this).attr('height'));
					newArray.push(newResolution);
				});
				
				setPref("resolutionArray", newArray);
				if(params.page == "main")
				{
					drawList(newArray);
				}
				else if(params.page == "options")
				{
					if(params.fromXML == null || params.fromXML == false)
					{
						backupArray = newArray;
					}
					drawOptionsList(newArray);
				}
			}
		});

	}
	else
	{
		console.log("Local storage loaded");
		if(params.page == "main")
		{
			drawList(resArray);
		}
		else if(params.page == "options")
		{
			if(params.fromXML == null || params.fromXML == false)
			{
				backupArray = resArray;
			}
			drawOptionsList(resArray);
		}
	}
	
	if(params.page == "options")
	{
		if(getPref("desktopNotifications"))
		{
			$('input#deskNotifCheckbox').attr("checked", true);
		}
		else
		{
			$('input#deskNotifCheckbox').attr("checked", false);
		}
		
		if(getPref("closeOnResize"))
		{
			$('input#closeBoxCheckbox').attr("checked", true);
		}
		else
		{
			$('input#closeBoxCheckbox').attr("checked", false);
		}
	}
	
	$('input#closeBoxCheckbox').change(function () {
												 
		if ($(this).attr("checked")) {
			setPref("closeOnResize", true);
			return;
		}
		
		setPref("closeOnResize", false);
	});
	
	$('input#deskNotifCheckbox').change(function () {
												 
		if ($(this).attr("checked")) {
			setPref("desktopNotifications", true);
			return;
		}
		
		setPref("desktopNotifications", false);
	});

}

//draw main popup list
function drawList(newArray)
{
	$('.resList').empty();
	
	var i = 0;
	for(i = 0; i < newArray.length; i++)
	{
		var width = newArray[i][0];
		var height = newArray[i][1];
		
		//$('body').append('<br>' + width);
		
		var newRow = '<li><img src="application_double.png" alt="" width="16" height="16" /><a href="javascript:changeWindowSize('+width+', '+height+', false)">'+width+' x '+height+'</a><input type="checkbox" name="list" id="checkbox'+i+'" /></li>';
					
		$('.resList').append(newRow);
	}
}

//draw options page list
function drawOptionsList(newArray, params)
{
	currentArray = newArray;
	
	$('.resList').empty();
	
	var i = 0;
	for(i = 0; i < newArray.length; i++)
	{
		var width = newArray[i][0];
		var height = newArray[i][1];
		
		//$('body').append('<br>' + width);
		
		var newRow = '<li id="entry'+i+'"><div onClick="removeEntry('+i+')" class="removeBtn"></div><div class="dragArrows"></div><img src="application_double.png" alt="" width="16" height="16" />'+width+' x '+height+'</li>';
					
		$('.resList').append(newRow);
	}
	
	if(params != null)
	{
		if(params.animateLast)
		{
			var entryNum = i-1;
			$('#entry'+entryNum).hide();
			$('#entry'+entryNum).slideDown(300);
		}
	}
	
	$(".resList").sortable( "destroy" );
	$(".resList").sortable({ axis: 'y', cursor: 'crosshair', handle: '.dragArrows', stop: onSortStop});
}

function onSortStop()
{
	var result = $('.resList').sortable('toArray');
	var elementNums = new Array();
	for(var i = 0; i < result.length; i++)
	{
		elementNums.push(parseInt(result[i].split('entry').slice(-1)));
	}
	
	var newArray = new Array();
	for(i = 0; i < elementNums.length; i++)
	{
		newArray.push(currentArray[elementNums[i]]);
	}
	
	currentArray = newArray;
	setPref("resolutionArray", currentArray);
	drawOptionsList(currentArray);
	
}

function resetFromBackup()
{
	alert(backupArray);
	setPref("resolutionArray", backupArray);
	drawOptionsList(backupArray);
	alert(backupArray);
}

function resetFromXML()
{
	if(confirm("This can't be undone, are you sure you want to reset to defaults?"))
	{
		init({page: "options", fromXML: true});
	}
}

function Vector (x, y) {
    this.x = x;
    this.y = y;
}

//var windowInfo = chrome.windows.get(0);
//var i = 0;
//document.write("<h1>Hello World!</h1>");
//document.write(i);

function changeWindowSize(newWidth, newHeight, newWindow)
{
	
	var browserSizeCheckbox = document.forms['browserSizeForm'].elements['browserSizeCheckbox'];
	
	if(!newWindow)
	{
		
		chrome.windows.getCurrent(function(w) {
			chrome.windows.update(w.id, {width: newWidth, height: newHeight});
			document.getElementById("results").innerHTML = "<img src=\"information.png\"> Window size changed to: " + newWidth + " x " + newHeight;
		});
		
		
		if(browserSizeCheckbox.checked)
		{					
			chrome.tabs.getSelected(null, function(t) {
				chrome.tabs.update(t.id, {url: "browsersize.html?url=" + startURL});
			});
		}
	}
	else
	{		
		chrome.tabs.getSelected(null, function(t) {
											   
			var URL;	
			
			if(browserSizeCheckbox.checked)
			{					
				URL = "browsersize.html?url=" + t.url;
			}
			else
			{
				URL = t.url;
			}
			
			chrome.windows.create({url: URL, width: newWidth, height: newHeight});
		});
	}
	
	if(getPref("desktopNotifications") == true)
	{
		// Create a simple text notification:
		var notification = webkitNotifications.createNotification(
		  'icon48.png',  // icon url - can be relative
		  'Window Resized',  // notification title
		  'Window size changed to: ' + newWidth + ' x ' + newHeight   // notification body text
		);
		
		notification.show();
	}
	
	if(getPref("closeOnResize") == true)
	{
		window.close();
	}

		
	
}

function changeWindowSizeCustom()
{
	chrome.windows.getCurrent(function(w) {
		var newWidth = document.getElementById("widthInput").value;
		var newHeight = document.getElementById("heightInput").value;
		if(newWidth == "" || newHeight == "" || newWidth == "Width" || newHeight == "Height")
		{
			document.getElementById("results").innerHTML = "<img src=\"exclamation.png\"> Please fill in both fields";
		}
		else
		{
			newWidth = parseInt(newWidth);
			newHeight = parseInt(newHeight);
			changeWindowSize(newWidth, newHeight, false);
		}
	});
}

function getLink(i)
{
	if(i == 1)
	{
		chrome.tabs.create({url: "http://www.benbeckford.com"});
	}
	else if(i == 2)
	{
		chrome.tabs.create({url: "http://www.famfamfam.com"});
	}
}

function SetAllCheckBoxes(FormName, FieldName, CheckValue)
{
	if(!document.forms[FormName])
		return;
	var objCheckBoxes = document.forms[FormName].elements[FieldName];
	if(!objCheckBoxes)
		return;
	var countCheckBoxes = objCheckBoxes.length;
	if(!countCheckBoxes)
		objCheckBoxes.checked = CheckValue;
	else
		// set the check value for all check boxes
		for(var i = 0; i < countCheckBoxes; i++)
			objCheckBoxes[i].checked = CheckValue;
}

function InvertCheckBoxes(FormName, FieldName)
{
	if(!document.forms[FormName])
		return;
	var objCheckBoxes = document.forms[FormName].elements[FieldName];
	if(!objCheckBoxes)
		return;
	var countCheckBoxes = objCheckBoxes.length;
	if(!countCheckBoxes)
		objCheckBoxes.checked = !objCheckBoxes.checked;
	else
		// set the check value for all check boxes
		for(var i = 0; i < countCheckBoxes; i++)
			objCheckBoxes[i].checked = !objCheckBoxes[i].checked;
}

function resetWindow()
{
	changeWindowSize(startWidth, startHeight, false);
}

function openSelected(FormName, FieldName)
{
	var resolutionArray = new Array();
	resolutionArray.push(new Vector(640, 480));
	resolutionArray.push(new Vector(800, 600));
	resolutionArray.push(new Vector(1024, 768));
	resolutionArray.push(new Vector(1280, 600));
	resolutionArray.push(new Vector(1280, 800));
	resolutionArray.push(new Vector(1280, 960));
	resolutionArray.push(new Vector(1280, 1024));
	resolutionArray.push(new Vector(1440, 900));
	resolutionArray.push(new Vector(1600, 1200));
	resolutionArray.push(new Vector(1920, 1080));
	resolutionArray.push(new Vector(1920, 1200));
	
	if(!document.forms[FormName])
		return;
	var objCheckBoxes = document.forms[FormName].elements[FieldName];
	if(!objCheckBoxes)
		return;
	var countCheckBoxes = objCheckBoxes.length;
	if(!countCheckBoxes)
	{
		if(objCheckBoxes.checked)
		{
				changeWindowSize(resolutionArray[0].x, resolutionArray[0].y, true);
		}
	}			
	else
	{
		for(var i = 0; i < countCheckBoxes; i++)
		{
			if(objCheckBoxes[i].checked)
			{
				changeWindowSize(resolutionArray[i].x, resolutionArray[i].y, true);
			}
		}
	}
				
	
}

function showCustomBox()
{
	$('#customBox').slideDown(300);
}

function removeEntry(i)
{
	currentArray.splice(i, 1);
	setPref("resolutionArray", currentArray);
	$('#entry'+i).slideUp(300, function()
	{
		drawOptionsList(currentArray);
	});
}

function addEntry()
{
	var newWidth = document.getElementById("widthInput").value;
	var newHeight = document.getElementById("heightInput").value;
	
	var reg_isinteger = /^\d+$/;
	
	if(newWidth != "" && newHeight != "" && reg_isinteger.test(newWidth) && reg_isinteger.test(newHeight))
	{
		var newResolution = new Array(2);
		newResolution[0] = newWidth;
		newResolution[1] = newHeight;
		currentArray.push(newResolution);
		setPref("resolutionArray", currentArray);
		drawOptionsList(currentArray, {animateLast: true});
	}
	else
	{
		$('#notify').slideDown(300).delay(1500).slideUp(300);
	}
}

function setPref(key, value) {
	if(!local)
	{
		var config = {};
		if (localStorage.config) {
			config = JSON.parse(localStorage.config);
		}
		config[key] = value;
		localStorage.config = JSON.stringify(config);
	}
}

function getPref(key) {
	if(!local)
	{
		if (!localStorage.config) {
			return undefined;
		}
		var config = JSON.parse(localStorage.config);
		return config[key];
	}
	else
	{
		return null;
	}
}

function openOptions()
{
	window.open(chrome.extension.getURL("options.html"));
}