[About]
jsshell is a small command window placed at the bottom of your Chrome browser that lets you run jQuery and jLinq commands no matter what page you're on! Just type in a script into the editor then press CTRL+Enter to run it!

[Blog Posts]
http://somewebguy.wordpress.com/?s=jsshell