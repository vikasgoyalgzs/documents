/*
(c) Copyright 2009 iOpus Software GmbH - http://www.iopus.com
*/


var version_string = "VERSION BUILD=8050528 RECORDER=CR";